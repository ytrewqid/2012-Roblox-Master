import base from '../controllers/base';
export default base;