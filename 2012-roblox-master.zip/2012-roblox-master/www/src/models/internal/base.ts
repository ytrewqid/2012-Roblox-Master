export interface IExtraData {
    cookie: string;
}