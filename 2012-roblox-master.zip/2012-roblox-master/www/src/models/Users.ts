export const Badges = [
    {
        name: 'Friendship',
        description: 'This badge is given to players who have embraced the Roblox community and have made at least 20 friends. People who have this badge are good people to know and can probably help you out if you are having trouble.',
        url: 'Friendship.png',
    }
]