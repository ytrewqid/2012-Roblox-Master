var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

jQuery.extend(jQuery.expr[':'], {
    focus: function(element)
    {
        return element == document.activeElement;
    }
});

}
/*
     FILE ARCHIVED ON 03:23:05 May 11, 2012 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 03:48:58 Jul 24, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  esindex: 0.014
  exclusion.robots.policy: 0.317
  exclusion.robots: 0.332
  captures_list: 133.995
  PetaboxLoader3.datanode: 261.335 (5)
  load_resource: 426.207
  LoadShardBlock: 66.255 (3)
  RedisCDXSource: 13.702
  CDXLines.iter: 27.262 (3)
  PetaboxLoader3.resolve: 101.986 (2)
*/