import { Controller, Get, QueryParams, Res } from '@tsed/common';
import { Summary } from '@tsed/swagger'
import base from '../base';

@Controller('/Catalog')
export class CatalogController extends base {


}